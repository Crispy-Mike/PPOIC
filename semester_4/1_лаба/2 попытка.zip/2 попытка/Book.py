class Book:
    def __init__(self, name_of_book, name_of_author, genre, content):
        self.name_of_book = name_of_book
        self.name_of_author = name_of_author
        self.genre = genre
        self.content = content
